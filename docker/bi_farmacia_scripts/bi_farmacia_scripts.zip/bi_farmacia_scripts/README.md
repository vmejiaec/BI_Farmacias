# Scripts de origen para la demostración de Inteligencia de Negocios

## Archivos

1. `01_mysql_creacion.sql`: estructura operacional de ventas e inventario.
2. `02_mysql_datos.sql`: datos de ventas e inventario, incluidos problemas deliberados de calidad.
3. `03_postgresql_creacion.sql`: estructura de gestión de clientes, sucursales, metas y satisfacción.
4. `04_postgresql_datos.sql`: datos de gestión y problemas deliberados de calidad.

## Problemas que deberá resolver el ETL

- Una misma sucursal aparece con nombres diferentes en MySQL.
- Los nombres oficiales y códigos de las sucursales están en PostgreSQL.
- Documentos de clientes contienen espacios, guiones, vacíos y valores sin correspondencia.
- Existen clientes duplicados y ciudades escritas de varias maneras.
- Las categorías `Analgésicos` y `Analgesicos` deberían consolidarse.
- Hay formas de pago con mayúsculas y minúsculas inconsistentes.
- Existen ventas anuladas, un precio unitario cero y una cantidad anómala.
- Hay encuestas con puntuación inválida y tiempos de espera extremos.
- Norte tiene productos de alta demanda con stock crítico.
- Valle posee inventario inmovilizado de productos de baja rotación.
- Sur presenta baja satisfacción y mayores tiempos de espera.
- Las metas comerciales solo pueden compararse con las ventas después de integrar ambas bases.

## Ejecución manual con los contenedores del docker-compose.yml

```bash
# MySQL
docker exec -i java_mysql mysql -uvictor -pvictor123 farmacia_db < 01_mysql_creacion.sql
docker exec -i java_mysql mysql -uvictor -pvictor123 farmacia_db < 02_mysql_datos.sql

# PostgreSQL
docker exec -i java_postgres psql -U victor -d farmacia_db < 03_postgresql_creacion.sql
docker exec -i java_postgres psql -U victor -d farmacia_db < 04_postgresql_datos.sql
```

## Nota sobre docker-compose.yml

El archivo actual monta `./data` únicamente en el contenedor MySQL. PostgreSQL no ejecutará automáticamente sus scripts. Para automatizar ambos motores conviene usar dos carpetas independientes, por ejemplo `./mysql-init` y `./postgres-init`, montadas en `/docker-entrypoint-initdb.d` de cada servicio.

Los scripts de inicialización se ejecutan automáticamente solo cuando el volumen de datos está vacío. Si los contenedores ya fueron iniciados, use los comandos manuales anteriores o elimine los volúmenes deliberadamente con `docker compose down -v` antes de reinicializar.
